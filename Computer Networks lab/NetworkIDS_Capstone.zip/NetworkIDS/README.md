# Network Intrusion Detection System Using Machine Learning

A professional cybersecurity capstone project using Random Forest to detect network intrusions from CICIDS2017 network traffic data.

## 🚀 Quick Start

```bash
pip install -r requirements.txt
python app.py
# Open http://localhost:5000
```

## 📁 Project Structure
```
NetworkIDS/
├── app.py               # Flask backend
├── model.pkl            # Trained Random Forest model
├── model_meta.json      # Model performance metrics
├── requirements.txt
├── sample_traffic_test.csv  # Demo CSV (1000 rows, balanced)
├── uploads/             # Temporary upload directory
├── static/
│   ├── css/style.css    # Cybersecurity dark theme
│   └── js/              # main.js, detection.js, results.js
└── templates/           # 7 Jinja2 HTML templates
```

## 🎯 Model Performance (Trained on CICIDS2017)
- Accuracy:  99.98%
- Precision: 99.99%
- Recall:    99.96%
- F1-Score:  99.98%

## 🔍 Detected Attack Types
- DDoS (128,027 samples)
- PortScan (158,930 samples)
- FTP-Patator / Brute Force
- Web Attacks (XSS, SQLi, Brute Force)

## 📊 Dataset
- Source: CICIDS2017 (Canadian Institute for Cybersecurity)
- Total records trained on: 732,578
- Features: 78 network flow features

## 💻 Tech Stack
- Backend: Python Flask
- ML: Scikit-Learn Random Forest
- Frontend: Bootstrap 5, Chart.js, Vanilla JS
- Theme: Dark Cybersecurity / Glassmorphism

## 🧪 Testing
Upload `sample_traffic_test.csv` on the Detection page for a demo.
