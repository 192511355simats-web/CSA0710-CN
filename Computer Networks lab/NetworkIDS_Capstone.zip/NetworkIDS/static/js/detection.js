/* ===== DETECTION PAGE JAVASCRIPT ===== */

document.addEventListener('DOMContentLoaded', () => {
  const zone     = document.getElementById('upload-zone');
  const fileIn   = document.getElementById('file-input');
  const browseBtn= document.getElementById('browse-btn');
  const analyzeBtn=document.getElementById('analyze-btn');
  const fileName = document.getElementById('file-name');
  const fileSize = document.getElementById('file-size');
  const fileInfo = document.getElementById('file-info');
  const loader   = document.getElementById('scan-loader');
  const logBox   = document.getElementById('scan-log');
  const progBar  = document.getElementById('prog-bar');
  let   selectedFile = null;

  const logLines = [
    '[ SYS ] Initializing Network IDS Engine...',
    '[ OK  ] Random Forest model loaded (model.pkl)',
    '[ OK  ] 78 feature columns verified',
    '[ INF ] Reading CSV file...',
    '[ INF ] Preprocessing data (inf/NaN handling)...',
    '[ INF ] Running Random Forest classifier...',
    '[ OK  ] Prediction complete!',
    '[ INF ] Building results dashboard...',
  ];

  // ─── Drag & Drop ────────────────────────────────
  zone.addEventListener('dragover', e => { e.preventDefault(); zone.classList.add('drag-over'); });
  zone.addEventListener('dragleave', ()=> zone.classList.remove('drag-over'));
  zone.addEventListener('drop', e => {
    e.preventDefault();
    zone.classList.remove('drag-over');
    const f = e.dataTransfer.files[0];
    if (f) handleFile(f);
  });
  zone.addEventListener('click', () => fileIn.click());
  browseBtn && browseBtn.addEventListener('click', e => { e.stopPropagation(); fileIn.click(); });
  fileIn.addEventListener('change', () => { if (fileIn.files[0]) handleFile(fileIn.files[0]); });

  function handleFile(f) {
    if (!f.name.endsWith('.csv')) { showToast('⚠ Please select a .csv file', 'error'); return; }
    selectedFile = f;
    fileName.textContent = f.name;
    fileSize.textContent = (f.size / 1024).toFixed(1) + ' KB';
    fileInfo.style.display = 'block';
    analyzeBtn.disabled = false;
    showToast('✔ File selected: ' + f.name, 'success');
  }

  // ─── Analyze ─────────────────────────────────────
  analyzeBtn && analyzeBtn.addEventListener('click', async () => {
    if (!selectedFile) return;
    analyzeBtn.disabled = true;
    zone.style.display  = 'none';
    loader.style.display = 'block';
    logBox.textContent  = '';
    progBar.style.width = '0%';

    // Fake log stream
    for (let i = 0; i < logLines.length; i++) {
      await sleep(350 + Math.random() * 300);
      logBox.textContent += logLines[i] + '\n';
      logBox.scrollTop = logBox.scrollHeight;
      progBar.style.width = ((i + 1) / logLines.length * 80) + '%';
    }

    const fd = new FormData();
    fd.append('file', selectedFile);

    try {
      const res  = await fetch('/api/predict', { method: 'POST', body: fd });
      const data = await res.json();

      if (data.error) { throw new Error(data.error); }

      progBar.style.width = '100%';
      await sleep(400);
      logBox.textContent += '[ OK  ] Analysis complete! Redirecting...\n';
      await sleep(600);

      sessionStorage.setItem('nids_results', JSON.stringify(data));
      window.location.href = '/results';

    } catch (err) {
      loader.style.display = 'none';
      zone.style.display   = 'block';
      analyzeBtn.disabled  = false;
      showToast('⚠ Error: ' + err.message, 'error');
    }
  });

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
});
