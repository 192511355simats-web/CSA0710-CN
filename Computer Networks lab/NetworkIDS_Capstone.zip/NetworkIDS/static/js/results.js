/* ===== RESULTS DASHBOARD JAVASCRIPT ===== */

document.addEventListener('DOMContentLoaded', () => {
  const raw = sessionStorage.getItem('nids_results');
  if (!raw) {
    document.getElementById('no-data').style.display = 'block';
    return;
  }
  const data = JSON.parse(raw);
  document.getElementById('results-content').style.display = 'block';

  const fmt = n => Number(n).toLocaleString();

  // ─── Metrics ────────────────────────────────────────
  document.getElementById('m-total').textContent    = fmt(data.total);
  document.getElementById('m-normal').textContent   = fmt(data.normal);
  document.getElementById('m-attacks').textContent  = fmt(data.attacks);
  document.getElementById('m-rate').textContent     = data.detection_rate + '%';
  document.getElementById('m-accuracy').textContent = data.accuracy + '%';
  document.getElementById('m-ts').textContent       = data.timestamp;

  const tBadge = document.getElementById('threat-badge');
  tBadge.textContent = '⚡ THREAT LEVEL: ' + data.threat_level;
  tBadge.className   = 'threat-badge threat-' + data.threat_class;

  const rec = document.getElementById('recommendation');
  const recMap = {
    secure:   '✅ Network traffic appears normal. No immediate action required. Continue routine monitoring.',
    low:      '🔵 Low-level threats detected. Review flagged flows and update firewall rules as needed.',
    medium:   '🟡 Suspicious activity detected. Investigate flagged connections immediately.',
    high:     '🟠 High threat level! Isolate affected network segments and investigate alerts now.',
    critical: '🔴 CRITICAL: Severe intrusion detected! Activate incident response protocol immediately.',
  };
  rec.textContent = recMap[data.threat_class] || '';

  // ─── Pie Chart – Normal vs Attack ───────────────────
  new Chart(document.getElementById('pieChart'), {
    type: 'doughnut',
    data: {
      labels: ['Normal Traffic', 'Attack Traffic'],
      datasets: [{
        data: [data.normal, data.attacks],
        backgroundColor: ['rgba(0,255,136,0.7)', 'rgba(255,0,85,0.7)'],
        borderColor:     ['#00ff88', '#ff0055'],
        borderWidth: 2,
        hoverOffset: 12,
      }],
    },
    options: {
      responsive: true,
      cutout: '65%',
      plugins: {
        legend: { labels: { color: '#e0f0ff', font: { size: 12 } } },
        tooltip: { callbacks: { label: ctx => `${ctx.label}: ${ctx.parsed.toLocaleString()} (${((ctx.parsed/data.total)*100).toFixed(1)}%)` } },
      },
    },
  });

  // ─── Bar Chart – Attack Distribution ────────────────
  const distLabels = Object.keys(data.attack_distribution);
  const distVals   = Object.values(data.attack_distribution);
  const barColors  = ['#ff0055','#ff6600','#ffcc00','#8b5cf6','#00d4ff','#00ff88'];

  if (distLabels.length > 0) {
    new Chart(document.getElementById('barChart'), {
      type: 'bar',
      data: {
        labels: distLabels,
        datasets: [{
          label: 'Attack Count',
          data: distVals,
          backgroundColor: distLabels.map((_, i) => barColors[i % barColors.length] + '99'),
          borderColor:     distLabels.map((_, i) => barColors[i % barColors.length]),
          borderWidth: 2,
          borderRadius: 6,
        }],
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: {
          x: { ticks: { color: '#5a7a9a' }, grid: { color: 'rgba(0,212,255,0.07)' } },
          y: { ticks: { color: '#5a7a9a' }, grid: { color: 'rgba(0,212,255,0.07)' } },
        },
      },
    });
  } else {
    document.getElementById('barChart').parentElement.innerHTML =
      '<p style="color:var(--text-muted);text-align:center;padding:2rem">No attacks detected</p>';
  }

  // ─── Severity Doughnut ───────────────────────────────
  const sevColors = { Critical:'#ff0055', High:'#ff6600', Medium:'#ffcc00', Low:'#00d4ff' };
  const sd = data.severity_distribution;
  const sevLabels = Object.keys(sd).filter(k => sd[k] > 0);
  const sevVals   = sevLabels.map(k => sd[k]);

  if (sevVals.some(v => v > 0)) {
    new Chart(document.getElementById('sevChart'), {
      type: 'doughnut',
      data: {
        labels: sevLabels,
        datasets: [{
          data: sevVals,
          backgroundColor: sevLabels.map(k => sevColors[k] + '99'),
          borderColor:     sevLabels.map(k => sevColors[k]),
          borderWidth: 2,
        }],
      },
      options: {
        responsive: true,
        cutout: '55%',
        plugins: { legend: { labels: { color: '#e0f0ff', font: { size: 11 } } } },
      },
    });
  }

  // ─── Results Table (top 200 rows) ────────────────────
  const tbody = document.getElementById('results-tbody');
  const rows  = data.rows || [];
  const PAGE  = 25;
  let   page  = 0;

  function renderTable() {
    const slice = rows.slice(page * PAGE, (page + 1) * PAGE);
    tbody.innerHTML = slice.map(r => `
      <tr>
        <td>#${r.index}</td>
        <td><span class="badge-severity badge-${r.prediction === 'Attack' ? 'high' : 'none'}" style="font-size:.75rem">
          ${r.prediction === 'Attack' ? '⚠ Attack' : '✓ Normal'}
        </span></td>
        <td>${r.attack_type}</td>
        <td>${r.confidence}%</td>
        <td><span class="badge-severity badge-${r.severity.toLowerCase()}">${r.severity}</span></td>
        <td style="font-size:.75rem;color:var(--text-muted)">${r.true_label !== 'N/A' ? r.true_label : '—'}</td>
        <td style="font-size:.75rem;max-width:180px;overflow:hidden;text-overflow:ellipsis">${r.action}</td>
      </tr>`).join('');
    document.getElementById('page-info').textContent = `Page ${page+1} / ${Math.ceil(rows.length/PAGE)}`;
  }

  renderTable();
  document.getElementById('prev-page').addEventListener('click', () => { if (page > 0) { page--; renderTable(); }});
  document.getElementById('next-page').addEventListener('click', () => { if ((page+1)*PAGE < rows.length) { page++; renderTable(); }});

  // ─── Export CSV ──────────────────────────────────────
  document.getElementById('export-btn').addEventListener('click', () => {
    const headers = ['#','Prediction','Attack Type','Confidence','Severity','True Label','Recommended Action'];
    const csvRows = [headers.join(',')];
    rows.forEach(r => {
      csvRows.push([r.index, r.prediction, r.attack_type, r.confidence+'%', r.severity, r.true_label, `"${r.action}"`].join(','));
    });
    const blob = new Blob([csvRows.join('\n')], { type: 'text/csv' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url; a.download = 'nids_results.csv'; a.click();
    URL.revokeObjectURL(url);
    showToast('✔ CSV exported!', 'success');
  });

  // Counter animations
  const mIds = ['m-total','m-normal','m-attacks'];
  const mVals = [data.total, data.normal, data.attacks];
  mIds.forEach((id,i) => {
    const el = document.getElementById(id);
    animateCounter(el, mVals[i]);
  });

  function animateCounter(el, target) {
    let cur = 0; const steps = 60; const inc = target / steps;
    const t = setInterval(() => {
      cur = Math.min(cur + inc, target);
      el.textContent = Math.round(cur).toLocaleString();
      if (cur >= target) clearInterval(t);
    }, 20);
  }
});
