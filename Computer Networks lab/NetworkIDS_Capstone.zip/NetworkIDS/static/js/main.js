/* ===== NETWORK IDS - MAIN JAVASCRIPT ===== */

// ─── Matrix Rain Background ────────────────────────────────────────
function initMatrix() {
  const canvas = document.createElement('canvas');
  const ctx    = canvas.getContext('2d');
  const wrap   = document.getElementById('matrix-bg');
  if (!wrap) return;
  wrap.appendChild(canvas);

  const resize = () => {
    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;
  };
  resize();
  window.addEventListener('resize', resize);

  const chars   = '01アイウエオカキクケコNETWORKINTRUSIONDETECTION';
  const fontSize = 13;
  let cols     = Math.floor(canvas.width / fontSize);
  let drops    = Array(cols).fill(1);

  function draw() {
    ctx.fillStyle = 'rgba(2,11,20,0.07)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = 'rgba(0,212,255,0.4)';
    ctx.font      = `${fontSize}px "Share Tech Mono", monospace`;
    for (let i = 0; i < drops.length; i++) {
      const c = chars[Math.floor(Math.random() * chars.length)];
      ctx.fillStyle = i % 7 === 0 ? 'rgba(0,255,136,0.5)' : 'rgba(0,212,255,0.3)';
      ctx.fillText(c, i * fontSize, drops[i] * fontSize);
      if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) drops[i] = 0;
      drops[i]++;
    }
    cols  = Math.floor(canvas.width / fontSize);
    drops = drops.length !== cols ? Array(cols).fill(1) : drops;
  }
  setInterval(draw, 55);
}

// ─── Typing Animation ──────────────────────────────────────────────
function initTyping() {
  const el = document.querySelector('.typing-text');
  if (!el) return;
  const lines = [
    'Analyzing network traffic patterns...',
    'Random Forest model loaded ✓',
    'CICIDS2017 dataset: 732,578 records',
    'Accuracy: 99.98% | F1-Score: 99.98%',
    'System ready for intrusion detection.',
  ];
  let li = 0, ci = 0, erasing = false;
  setInterval(() => {
    const cur = lines[li];
    if (!erasing) {
      el.textContent = cur.slice(0, ++ci);
      if (ci >= cur.length) { erasing = true; setTimeout(() => {}, 1500); }
    } else {
      el.textContent = cur.slice(0, --ci);
      if (ci === 0) { erasing = false; li = (li + 1) % lines.length; }
    }
  }, 55);
}

// ─── Counter Animation ─────────────────────────────────────────────
function animateCounter(el, target, suffix = '') {
  const dur   = 1800;
  const step  = 16;
  const steps = dur / step;
  let cur     = 0;
  const inc   = target / steps;
  const timer = setInterval(() => {
    cur = Math.min(cur + inc, target);
    el.textContent = Math.round(cur).toLocaleString() + suffix;
    if (cur >= target) clearInterval(timer);
  }, step);
}

function initCounters() {
  document.querySelectorAll('[data-count]').forEach(el => {
    const target = parseFloat(el.dataset.count);
    const suffix = el.dataset.suffix || '';
    const obs = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) {
        animateCounter(el, target, suffix);
        obs.disconnect();
      }
    }, { threshold: 0.5 });
    obs.observe(el);
  });
}

// ─── Navbar Active Highlight ───────────────────────────────────────
function initNavActive() {
  const path = window.location.pathname;
  document.querySelectorAll('.nav-link').forEach(a => {
    const href = a.getAttribute('href');
    if (href === path || (href !== '/' && path.startsWith(href))) {
      a.classList.add('active');
    }
  });
}

// ─── Global Toast ──────────────────────────────────────────────────
function showToast(msg, type = 'info') {
  let wrap = document.getElementById('toast-wrap');
  if (!wrap) {
    wrap = document.createElement('div');
    wrap.id = 'toast-wrap';
    wrap.style.cssText = 'position:fixed;bottom:1.5rem;right:1.5rem;z-index:9999;display:flex;flex-direction:column;gap:.5rem;';
    document.body.appendChild(wrap);
  }
  const t = document.createElement('div');
  const colors = { success: '#00ff88', error: '#ff0055', info: '#00d4ff', warn: '#ffcc00' };
  t.style.cssText = `background:rgba(4,28,52,0.95);border:1px solid ${colors[type]||'#00d4ff'};
    color:${colors[type]||'#00d4ff'};padding:.75rem 1.2rem;border-radius:8px;font-size:.85rem;
    font-family:'Share Tech Mono',monospace;backdrop-filter:blur(16px);
    animation:slideInRight .3s ease;max-width:300px;`;
  t.textContent = msg;
  wrap.appendChild(t);
  setTimeout(() => t.remove(), 3500);
}

// ─── Init All ──────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initMatrix();
  initTyping();
  initCounters();
  initNavActive();
});
