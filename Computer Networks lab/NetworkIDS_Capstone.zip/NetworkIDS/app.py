import os
import json
import uuid
import numpy as np
import pandas as pd
import joblib
from flask import Flask, render_template, request, jsonify, session
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

app = Flask(__name__)
app.secret_key = 'nids-capstone-2024-secret'
UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Load model and metadata
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'model.pkl')
META_PATH  = os.path.join(os.path.dirname(__file__), 'model_meta.json')

model = joblib.load(MODEL_PATH)
with open(META_PATH) as f:
    model_meta = json.load(f)

FEATURE_COLS = model_meta['feature_cols']

ATTACK_INFO = {
    'DDoS':            {'severity': 'Critical', 'color': '#ff0055', 'action': 'Block source IPs immediately and activate DDoS mitigation.'},
    'PortScan':        {'severity': 'High',     'color': '#ff6600', 'action': 'Firewall suspicious IPs and audit open ports.'},
    'FTP-Patator':     {'severity': 'High',     'color': '#ff6600', 'action': 'Disable FTP or enforce strong credentials and rate-limiting.'},
    'Web Attack':      {'severity': 'Medium',   'color': '#ffcc00', 'action': 'Patch web application, enable WAF rules.'},
    'Infiltration':    {'severity': 'Critical', 'color': '#ff0055', 'action': 'Isolate affected hosts and perform forensic analysis.'},
    'Botnet':          {'severity': 'Critical', 'color': '#ff0055', 'action': 'Quarantine infected machines, reset credentials.'},
    'DoS':             {'severity': 'High',     'color': '#ff6600', 'action': 'Rate-limit connections, contact upstream provider.'},
    'BENIGN':          {'severity': 'Low',      'color': '#00ff88', 'action': 'No action required.'},
}

def classify_attack_type(label):
    label = str(label)
    for k in ATTACK_INFO:
        if k.lower() in label.lower():
            return k
    return 'Unknown'

def get_threat_level(attack_pct):
    if attack_pct == 0:   return 'SECURE',  'secure'
    if attack_pct < 5:    return 'LOW',      'low'
    if attack_pct < 20:   return 'MEDIUM',   'medium'
    if attack_pct < 50:   return 'HIGH',     'high'
    return 'CRITICAL', 'critical'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/dataset')
def dataset():
    label_counts = model_meta.get('label_counts', {})
    clean_counts = {}
    for k, v in label_counts.items():
        clean_key = k.replace('\ufffd', '').replace('  ', ' ').strip()
        clean_counts[clean_key] = v
    return render_template('dataset.html', label_counts=clean_counts, meta=model_meta)

@app.route('/model')
def model_page():
    return render_template('model.html', meta=model_meta)

@app.route('/detection')
def detection():
    return render_template('detection.html')

@app.route('/results')
def results():
    return render_template('results.html')

@app.route('/alerts')
def alerts():
    return render_template('alerts.html')

@app.route('/api/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400

    f = request.files['file']
    if not f.filename.endswith('.csv'):
        return jsonify({'error': 'Please upload a CSV file'}), 400

    fname = f'{uuid.uuid4().hex}.csv'
    fpath = os.path.join(UPLOAD_FOLDER, fname)
    f.save(fpath)

    try:
        df_raw = pd.read_csv(fpath, low_memory=False)
        df_raw.columns = df_raw.columns.str.strip()

        has_label = 'Label' in df_raw.columns
        true_labels = df_raw['Label'].tolist() if has_label else None

        # Build feature matrix
        missing = [c for c in FEATURE_COLS if c not in df_raw.columns]
        for m in missing:
            df_raw[m] = 0

        X = df_raw[FEATURE_COLS].copy()
        X.replace([np.inf, -np.inf], np.nan, inplace=True)
        for col in X.columns:
            X[col] = pd.to_numeric(X[col], errors='coerce')
        X.fillna(X.median(), inplace=True)

        preds = model.predict(X)
        proba = model.predict_proba(X)[:, 1]

        total   = len(preds)
        attacks = int(preds.sum())
        normal  = total - attacks
        det_rate = round(attacks / total * 100, 2) if total else 0
        threat_label, threat_class = get_threat_level(det_rate)

        # Build per-row results
        rows = []
        for i, (pred, prob) in enumerate(zip(preds, proba)):
            true_lbl = true_labels[i] if has_label else 'N/A'
            atype = classify_attack_type(true_lbl) if (pred == 1 and has_label) else ('Attack' if pred == 1 else 'BENIGN')
            info  = ATTACK_INFO.get(atype, ATTACK_INFO.get('BENIGN'))
            rows.append({
                'index': i + 1,
                'prediction': 'Attack' if pred == 1 else 'Normal',
                'confidence': round(float(prob) * 100, 2),
                'true_label': true_lbl,
                'attack_type': atype if pred == 1 else 'Normal Traffic',
                'severity': info['severity'] if pred == 1 else 'None',
                'action': info['action'] if pred == 1 else 'No action required.',
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            })

        # Attack type distribution for charts
        attack_dist = {}
        for row in rows:
            if row['prediction'] == 'Attack':
                t = row['attack_type']
                attack_dist[t] = attack_dist.get(t, 0) + 1

        # Severity distribution
        sev_dist = {'Critical': 0, 'High': 0, 'Medium': 0, 'Low': 0}
        for row in rows:
            if row['prediction'] == 'Attack':
                s = row['severity']
                sev_dist[s] = sev_dist.get(s, 0) + 1

        alerts_list = [r for r in rows if r['prediction'] == 'Attack'][:100]

        result = {
            'total': total,
            'normal': normal,
            'attacks': attacks,
            'detection_rate': det_rate,
            'threat_level': threat_label,
            'threat_class': threat_class,
            'attack_distribution': attack_dist,
            'severity_distribution': sev_dist,
            'rows': rows[:200],
            'alerts': alerts_list,
            'accuracy': model_meta['accuracy'],
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        }

        os.remove(fpath)
        return jsonify(result)

    except Exception as e:
        if os.path.exists(fpath):
            os.remove(fpath)
        return jsonify({'error': str(e)}), 500

@app.route('/api/model_info')
def model_info():
    return jsonify(model_meta)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
